unit class SVG::Plot::Data::Marker;

has $.brush;            # TODO: default value
has $.color = 'black';  # TODO: object
has $.inside_color = 'black';
has Numeric $.key;
has Numeric $.value;
has Numeric $.key2;
has Numeric $.value2;

# vim: ft=perl6
