# Name Acme::WTF

WTF is this? Really

# Synopsis

use Acme::WTF;

die "What is life?";

# Author

He prefers to stay anonymous. Forget the Meta.info file
