use v6;
use PDF::Storage::Input;

class PDF::Storage::Input::Str
    is PDF::Storage::Input
    is Str {
}
