use v6;

use PDF::Grammar::Doc::Actions;

# rules for constructing PDF::Grammar::FDF AST                                                                                                 
class PDF::Grammar::FDF::Actions
    is PDF::Grammar::Doc::Actions {
}
