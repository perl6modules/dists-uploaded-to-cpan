p6-lingua-en-syllable
=====================

Port of perl5 module of same name [1]

This module guesses at the number of syllables in an English word.

[1] http://search.cpan.org/~gregfast/Lingua-EN-Syllable-0.251/Syllable.pm
    original by Greg Fast
