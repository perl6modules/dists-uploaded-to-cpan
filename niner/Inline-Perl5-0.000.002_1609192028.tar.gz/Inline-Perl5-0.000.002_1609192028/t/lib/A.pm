package A;

sub new {
    return bless {};
}

1;
