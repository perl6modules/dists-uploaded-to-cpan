package P5ModuleVersion;

our $VERSION = '1.0';

1;
