package Foo::Bar::TestV6Sub;

use strict;
use warnings;

use base qw(Foo::Bar::TestV6);

1;
