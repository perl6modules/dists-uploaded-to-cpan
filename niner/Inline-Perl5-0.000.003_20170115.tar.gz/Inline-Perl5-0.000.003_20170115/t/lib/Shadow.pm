package Shadow;

sub new {
    return bless {};
}

sub list {
    return 'list';
}

sub end {
    return 'end';
}

sub say {
    return 'say';
}

sub print {
    return 'print';
}

sub note {
    return 'note';
}

sub put {
    return 'put';
}

sub split {
    return 'split';
}

1;
