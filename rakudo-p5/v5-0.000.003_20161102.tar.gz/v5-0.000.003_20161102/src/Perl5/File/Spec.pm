
use v6;

class File::Spec is IO::Spec { }

multi sub EXPORT(*@ops) { my %o }

