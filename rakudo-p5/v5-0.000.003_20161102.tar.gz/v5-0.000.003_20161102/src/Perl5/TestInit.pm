
use v6;

module TestInit {
}

sub EXPORT(*@ops) {
    my %o;
    %o
}

