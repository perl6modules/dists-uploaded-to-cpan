
unit class Perl5::World;



# vim: ft=perl6
