use v6;

role CSS::Grammar::AST::Info {
    # $.line-no - source line number
    has Int $.line-no is rw;
}
