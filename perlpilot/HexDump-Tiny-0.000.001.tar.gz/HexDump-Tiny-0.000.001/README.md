Name
====

HexDump::Tiny

Synopsis
========

    #!/usr/bin/env perl6

    use HexDump::Tiny;

    .say for hexdump(slurp("filename"));

Description
===========

Generate a hexdump from a scalar.
