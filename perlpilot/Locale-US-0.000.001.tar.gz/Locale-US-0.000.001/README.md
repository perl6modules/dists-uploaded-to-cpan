# Locale::US

A Perl 6 module for mapping two character state abbreviations for United
States territories to their state name and vice versa. This module was
very much inspired by the Perl 5 module of the same name.
