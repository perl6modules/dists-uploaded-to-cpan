prove -e 'perl6 -I ./lib' t
