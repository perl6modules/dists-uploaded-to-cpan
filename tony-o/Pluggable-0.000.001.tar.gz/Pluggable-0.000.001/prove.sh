#!/bin/bash

prove -e 'perl6 -Ilib -It/lib' t/*
