#HTML::Parser

A role intended to define a standard interface for anything wanting to be an HTML parser (ensures portable drop in replacements)

skarsnik++
