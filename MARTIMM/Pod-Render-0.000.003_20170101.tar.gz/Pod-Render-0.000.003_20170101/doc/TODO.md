 #Todo and Bugs

 * Add a specific perl6 styles file in javascript. Examples at prettify site.
