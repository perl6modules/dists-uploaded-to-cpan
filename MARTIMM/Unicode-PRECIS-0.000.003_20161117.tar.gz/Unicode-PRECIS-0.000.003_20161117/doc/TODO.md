# Todo, Bugs and known limitations

* Try to use tables when uniprop is not available
* Try to use the highest possible unicode version when using tables. At the time of writing this is version 9.0.0.
* Documentation
