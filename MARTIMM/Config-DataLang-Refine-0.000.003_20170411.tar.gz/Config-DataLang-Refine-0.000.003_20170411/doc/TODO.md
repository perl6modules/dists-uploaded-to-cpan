# Todo and Bugs.

* Options in windows style output like **iptables /renew**.
