/* This is some C code */
#include <stdio.h>
void main (void) {
    printf "Hello\n";
}
