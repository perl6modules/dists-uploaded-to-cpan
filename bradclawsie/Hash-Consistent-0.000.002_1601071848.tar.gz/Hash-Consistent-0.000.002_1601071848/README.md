[![Build Status](https://travis-ci.org/bradclawsie/Hash-Consistent.png)](https://travis-ci.org/bradclawsie/Hash-Consistent)

A Perl6 implementation of a consistent hash. See perldocs for more details.
