[![Build Status](https://travis-ci.org/bradclawsie/Net-IP-Parse.png)](https://travis-ci.org/bradclawsie/Net-IP-Parse)

A library to provide types for well-formed IPv4 and IPv6 addresses,
as well as well-formed IPv4 and IPv6 CIDRs.

See the module pod for more information.

