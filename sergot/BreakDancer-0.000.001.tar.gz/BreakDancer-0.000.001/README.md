BreakDancer
===========

A framework for generating static webpages.


Examples
==========

* [sourcecode of poznan.pm.org](https://github.com/sergot/poznan.pm.org/blob/master/gen.p6 "Sourcecode of Poznan PM")
* [sourcecode of filip.sergot.pl](https://github.com/sergot/filip.sergot.pl/blob/static_perl6/gen.p6 "Sourcecode of filip.sergot.pl")
