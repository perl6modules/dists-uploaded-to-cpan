role Bailador::Template {
    method render($template, @params) { ... }
}
