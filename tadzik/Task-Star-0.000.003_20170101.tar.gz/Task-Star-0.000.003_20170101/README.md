# Task::Star

[![Build Status](https://travis-ci.org/tadzik/Task-Star.png)](https://travis-ci.org/tadzik/Task-Star) [![Build status](https://ci.appveyor.com/api/projects/status/github/tadzik/Task-Star?svg=true)](https://ci.appveyor.com/project/tadzik/Task-Star/branch/master)

Meta-package for modules included in Rakudo Star.

