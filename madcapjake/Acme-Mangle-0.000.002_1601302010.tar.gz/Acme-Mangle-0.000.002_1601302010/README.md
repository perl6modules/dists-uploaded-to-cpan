```
mangle "Hello from the other side. I must've called a thousand times."
```

### Thanks

[yoleaux](http://dpk.io/yoleaux)'s `.mangle` command

Jean-Yves Lefort's [libtranslate](http://www.nongnu.org/libtranslate/)
