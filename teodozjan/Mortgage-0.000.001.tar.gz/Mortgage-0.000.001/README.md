# mortgage6

Mortgage6 is little but usable library that allows to calculate all costs of mortage. Since banks give a lot of discounts if buying their products it is harder see the costs

## install
    panda install Mortgage

## doc
    p6doc Mortgage
or [POD](https://github.com/teodozjan/mortage6/blob/master/lib/Mortgage.pm6)
