perl-store
==========

.perl serialization class and module

This module will work only for only simple situations. All data that is not visible after calling [.perl](http://doc.perl6.org/routine/perl) method will be lost. This may be considered as limitation or feature. 
