# SYNOPSIS

Sparrowdo core-dsl functions. To be done.




