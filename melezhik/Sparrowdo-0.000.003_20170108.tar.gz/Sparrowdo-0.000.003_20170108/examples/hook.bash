run_story package-install
run_story user
run_story cpan-package-install
