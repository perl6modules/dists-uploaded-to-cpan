# Needed for full YAML support

- Complex mapping keys
- Empty values
- Block indentation indicator
- Block chomping indicator
- Flow node on new line
- Special null values (null)
