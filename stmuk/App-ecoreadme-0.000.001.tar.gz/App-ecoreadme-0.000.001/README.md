App::ecoreadme
==============

Currently most source present in the perl6 ecosystem on github has the
documentation in README.md or .txt rather than in POD.

So this script displays and caches these ecosystem README files from the
command line.

Pull requests welcome.

-- steve.mynott@gmail.com 20151006

# p6-app-p6tags
