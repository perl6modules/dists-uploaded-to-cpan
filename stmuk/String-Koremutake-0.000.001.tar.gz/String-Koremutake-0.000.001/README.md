# p6-String-Koremutake

Converts to and from Koremutake Memorable Random Strings.

Perl 6 (Rakudo) module which is shamelessly stolen from Léon Brocard's Perl 5
String-Koremutake.

Pull requests welcome.
