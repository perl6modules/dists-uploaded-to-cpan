Mousetrap is licensed under Apache 2.0 License according to https://github.com/ccampbell/mousetrap/blob/master/README.md

Please see http://www.apache.org/licenses/LICENSE-2.0.html.