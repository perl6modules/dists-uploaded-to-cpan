use v6;

my $x = 10;

say "Your number: $($x)";

say "Double your number: $($x * 2)";

say "Square your number $($x * $x)";
