Totem
=====

This is a experiment for a smart web-based search bar for Perl 6 development.
The backend server will be Perl 6 with an HTML/CSS/Javascript user interface.

- Create file /home/user/....
- Open file /home/z....
- Close
- Create directory
- Create project
- Read Find::Find document
- Open File::Find source code (as readonly)
