# Examples README

These examples were presented to Pittsburgh Perl Workshop 2015 as an [P6SGI
RFC](https://speakerdeck.com/zostay/perl-6-standard-gateway-interface-ppw-2015).

These examples are non-normative and (as of this writing) not tested to see if
they compile or work at all. Hopefully, these will be updated with the state of
the art at some point and/or moved somewhere else more appropriate.

