enum Hinges::StreamEventKind <start end text xml-decl doctype start-ns end-ns
                              start-cdata end-cdata pi comment empty expr>;

