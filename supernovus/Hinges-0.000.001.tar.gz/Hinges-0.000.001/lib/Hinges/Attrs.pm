use v6;

class Hinges::Attrs {
}
