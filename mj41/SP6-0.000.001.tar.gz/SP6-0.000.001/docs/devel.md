Run tests
---------

    perl6 -Ilib t/vars.t

Run all tests
--------------

    prove -e'perl6 -Ilib' t/
