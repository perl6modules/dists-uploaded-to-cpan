# Test Data

The sub-directory ```uritemplate-test``` contains the test data from
https://github.com/uri-templates/uritemplate-test and includes its
original README and license. I've imported this rather than made a
subproject as it doesn't appear to play well with the build tools.

If you want to include new test data please make a new directory and
create a new JSON file of the same format rather than alter the
existing files lest the refreshing of the data becomes difficult.
