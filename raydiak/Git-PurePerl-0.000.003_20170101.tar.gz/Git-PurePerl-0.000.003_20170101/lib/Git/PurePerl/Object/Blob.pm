use Git::PurePerl::Object;
unit class Git::PurePerl::Object::Blob is Git::PurePerl::Object;

has $.kind = 'blob';

# vim: ft=perl6
