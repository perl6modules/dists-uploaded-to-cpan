unit class Git::PurePerl::Actor;

has Str $.name = die 'name is required';
has Str $.email = die 'email is required';

# vim: ft=perl6
