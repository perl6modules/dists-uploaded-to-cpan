Adventure::Engine
=================

Class that runs an interactive fiction adventure game.

The class is meant to be wrapped by another class &mdash; see crypt for an
example &mdash; which then builds up the world using methods from this class.
It then exposes the common player commands, such as `walk` and `take` and
`use`.

Actual illucidating example coming soon. Watch this spot.
