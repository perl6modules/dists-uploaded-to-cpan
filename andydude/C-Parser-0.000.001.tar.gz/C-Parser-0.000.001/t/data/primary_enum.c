typedef enum MyBoolean {
    MyFalse,
    MyTrue
} MyBoolean_t;

enum MyBoolean enabled = MyTrue;
