typedef union {
  char __mbstate8[128];
} __mbstate_t;
