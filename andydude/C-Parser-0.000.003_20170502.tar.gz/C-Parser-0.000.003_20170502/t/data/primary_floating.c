float pi32 = 3.14f;
double pi64 = 3.14;
