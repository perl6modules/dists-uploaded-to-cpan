#!/bin/sh
cp t/basic-backup basic
cp t/multilang-backup multilang
