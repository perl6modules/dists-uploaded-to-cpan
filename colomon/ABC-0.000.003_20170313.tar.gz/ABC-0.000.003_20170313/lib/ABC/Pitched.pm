use v6;

role ABC::Pitched {
    method transpose($pitch-changer) { ... }
}
