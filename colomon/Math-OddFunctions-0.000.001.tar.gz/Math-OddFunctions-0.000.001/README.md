This simple module tries to implement the functions described in

    http://www.johndcook.com/blog/2010/06/07/math-library-functions-that-seem-unnecessary/

Ideally I think these should be in p6's core, but I thought having
a module for them would be a useful first step.
