= Ident::Client =

Implements an [RfC 1413](https://www.ietf.org/rfc/rfc1413.txt) compatible Ident client.

== Installation ==

Not yet, but once this gets into panda, you can use:

```panda update && panda install Ident::Client``

== Author ==

Yuvi Panda, yuvipanda on `#perl6`

== License ==

Artistic License 2.0
