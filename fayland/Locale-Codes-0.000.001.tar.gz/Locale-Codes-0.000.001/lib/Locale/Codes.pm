unit module Locale::Codes;

# nothing