# perl6-Business-CreditCard
Validate/generate credit card checksums/names


```
use Business::CreditCard;

say validate("5276 4400 6542 1319");
say cardtype("5276 4400 6542 1319");
```