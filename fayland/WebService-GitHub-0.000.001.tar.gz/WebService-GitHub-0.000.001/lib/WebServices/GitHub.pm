use v6;

use WebServices::GitHub::Role;
use WebServices::GitHub::OAuth;

class WebServices::GitHub does WebServices::GitHub::Role {
    # does WebServices::GitHub::Role::Debug if %*ENV<DEBUG_GITHUB>;

}