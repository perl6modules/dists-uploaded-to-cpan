P6-Compress-Zlib-Raw
====================

Low-level interface to zlib.

Will probably only work on 64bit *nix, due to hardcoded library name and sizeof
numbers.
