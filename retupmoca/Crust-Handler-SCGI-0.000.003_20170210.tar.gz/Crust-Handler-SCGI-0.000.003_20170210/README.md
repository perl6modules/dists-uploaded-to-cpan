# Crust::Handler::SCGI

    crustup -s SCGI --port 9010 app.psgi
