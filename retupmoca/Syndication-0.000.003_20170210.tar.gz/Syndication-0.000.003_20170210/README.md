# p6-syndication
