Documentation is in lib/MQTT/Client.pm
